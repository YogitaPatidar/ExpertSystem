-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2021 at 10:00 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `expertsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` varchar(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `password`, `name`, `email`) VALUES
('admin', '123', 'Yogita Patidar', 'yogi2603@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `categoryid` varchar(10) NOT NULL,
  `categoryname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryid`, `categoryname`) VALUES
('S7', 'Banking'),
('S2', 'Biology'),
('S3', 'Chemistry'),
('S11', 'Commerce'),
('S5', 'Cooking'),
('S9', 'Health'),
('S1', 'Maths'),
('S6', 'Music'),
('S12', 'Other'),
('S10', 'Photography'),
('S4', 'Physics'),
('S8', 'Programming');

-- --------------------------------------------------------

--
-- Table structure for table `expert`
--

CREATE TABLE `expert` (
  `expertid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `categoryid` varchar(12) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expert`
--

INSERT INTO `expert` (`expertid`, `name`, `email`, `password`, `categoryid`, `status`) VALUES
(1, 'Yogita Patidar', 'yogi2603@gmail.com', '123', 'S1', 0),
(2, 'Nishma Ahmed', 'nishi@gmail.com', '12345', 'S3', 0),
(3, 'Sakshi Prajapat', 'sakshi@gmail.com', '12345', 'S2', 0),
(4, 'Gouransh Thakur', 'gouransh@gmail.com', '12345', 'S5', 0),
(5, 'Nitya Patidar', 'nitya@gmail.com', '123', 'S4', 0),
(7, 'Nishma Ahmed', 'nishma@gmail.com', '123', 'S3', 0),
(8, 'Kapil Patidar', 'kapil@gmail.com', '12345', 'S8', 0),
(9, 'Kanushi Karma', 'kanushi@gmail.com', '12354tgtr', 'S5', 1),
(10, 'Manas Prajapat', 'manas@gmail.com', '12345', 'S11', 0);

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `queid` int(11) NOT NULL,
  `categoryid` varchar(10) NOT NULL,
  `title` longtext NOT NULL,
  `userid` int(11) NOT NULL,
  `datetime` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`queid`, `categoryid`, `title`, `userid`, `datetime`) VALUES
(1, 'S4', 'What is stress?', 1, '2021-04-29 10:28:08'),
(2, 'S4', 'What is strain?', 1, '2021-04-29 13:06:58'),
(3, 'S6', 'Types of music ?', 1, '2021-04-29 13:09:47'),
(4, 'S6', 'Types of music ?', 1, '2021-04-29 13:10:39'),
(5, 'S9', 'Herbs used to cure cough and cold ??', 1, '2021-04-29 13:12:56'),
(6, 'S4', 'Newton second law of motion .', 3, '2021-04-30 11:04:09'),
(7, 'S8', 'Write a program to print fibbonaci series .', 4, '2021-04-30 13:27:53'),
(8, 'S4', 'Newton law of cooling.', 3, '2021-06-12 16:15:23'),
(9, 'S8', 'What is swift   ?', 1, '2021-07-10 05:25:34'),
(10, 'S6', 'Types of musical instrument ?', 1, '2021-08-15 05:45:15'),
(19, 'S4', 'Difference between real and virtual image formation?', 1, '2021-12-02 15:55:42'),
(20, 'S1', 'difference between similar triangle and equilateral triangle?', 1, '2021-12-02 15:56:37'),
(21, 'S1', 'Using only an addition, how do you add eight 8s and get the number 1000?', 1, '2021-12-02 15:59:26'),
(22, 'S1', 'Sally is 54 years old and her mother is 80, how many years ago was Sallys mother times her age?', 1, '2021-12-02 16:00:19'),
(23, 'S1', 'Which 3 numbers have the same answer whether theyre added or multiplied together?', 1, '2021-12-02 16:00:56'),
(24, 'S1', 'There is a basket containing 5 apples, how do you divide the apples among 5 children so that each child has 1 apple while 1 apple remains in the basket?', 1, '2021-12-02 16:01:12'),
(25, 'S1', 'There is a three-digit number. The second digit is four times as big as the third digit, while the first digit is three less than the second digit. What is the number?', 1, '2021-12-02 16:01:38'),
(26, 'S1', 'You have a 3-litre bottle and a 5-litre bottle. How can you measure 4 litres of water by using 3L and 5L bottles? ', 1, '2021-12-02 16:02:10'),
(27, 'S1', 'How to get a number 100 by using four sevens (7s) and a one (1)?', 1, '2021-12-02 16:03:30'),
(28, 'S1', 'You have a 3-litre bottle and a 5-litre bottle. How can you measure 4 litres of water by using 3L and 5L bottles? ', 1, '2021-12-02 17:00:44'),
(29, 'S1', '  If x sin3|+ y cos3|=sin|cos| and xsin|=ycos|, prove x2+y2=1.', 1, '2021-12-02 20:10:46');

-- --------------------------------------------------------

--
-- Table structure for table `solution`
--

CREATE TABLE `solution` (
  `ansid` int(11) NOT NULL,
  `queid` int(11) NOT NULL,
  `answer` longtext NOT NULL,
  `expertid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `solution`
--

INSERT INTO `solution` (`ansid`, `queid`, `answer`, `expertid`, `userid`, `datetime`) VALUES
(1, 1, 'Stress is defined as “The restoring force per unit area of the material”. It is a tensor quantity. Denoted by Greek letter σ. Measured using Pascal or N/m2. Mathematically expressed as –\r\n\r\n \r\n\r\nσ\r\n=\r\nF\r\nA\r\nWhere,\r\nF is the restoring force measured in Newton or N.\r\nA is the area of cross-section measured in m2.\r\nσ is the stress measured using N/m2 or Pa.', 1, NULL, '2021-10-29 05:58:58'),
(2, 1, 'When the deforming force is applied to an object, the object deforms. In order to bring the object back to the original shape and size, there will be an opposing force generated inside the object.\r\n\r\nThis restoring force will be equal in magnitude and opposite in direction to the applied deforming force. The measure of this restoring force generated per unit area of the material is called stress.', 3, NULL, '2021-10-29 06:01:25'),
(3, 2, ' Strain is simply the measure of how much an object is streched or deformed.', 1, NULL, '2021-11-20 03:09:17'),
(4, 1, 'the restoring force per unit area', 5, NULL, '2021-11-20 05:40:18'),
(5, 6, ' Newton second law is a quantitative description of the changes that a force can produce on the motion of a body. It states that the time rate of change of the momentum of a body is equal in both magnitude and direction to the force imposed on it.', 5, NULL, '2021-11-24 06:11:02'),
(6, 6, 'formula??', NULL, 3, '2021-11-24 08:29:33'),
(7, 1, 'Unit- Pascal or N/m2.', NULL, 1, '2021-11-24 11:45:57'),
(8, 1, 'Unit- Pascal or N/m2.', NULL, 1, '2021-11-29 09:58:21'),
(9, 1, 'Unit- Pascal or N/m2.', NULL, 1, '2021-11-30 06:59:17'),
(10, 26, 'First, fill 3Lt bottle and pour 3 litres into 5Lt bottle.\r\n\r\nAgain fill the 3Lt bottle. Now pour 2 litres into the 5Lt bottle until it becomes full.\r\n\r\nNow empty 5Lt bottle.\r\n\r\nPour remaining 1 litre in 3Lt bottle into 5Lt bottle.\r\n\r\nNow again fill 3Lt bottle and pour 3 litres into 5Lt bottle.\r\n\r\nNow you have 4 litres in the 5Lt bottle. Thats it.', 1, NULL, '2021-12-02 16:27:20'),
(11, 20, 'All regular polygons with the same number of sides are similar to each other. An equilateral triangle is a regular polygon with 3 sides, so all equilateral triangles are similar.', 1, NULL, '2021-12-02 16:29:55'),
(12, 26, ' First, fill the 5Lt bottle and pour 3 litres into 3Lt bottle.\r\n\r\nEmpty 3Lt bottle.\r\n\r\nPour remaining 2 litres in  5Lt bottle into 3Lt bottle.\r\n\r\nAgain fill the 5Lt bottle and pour 1 litre into 3 Lt bottle until it becomes full.\r\n\r\nNow you have 4 litres in the 5Lt bottle. Thats it.', 1, NULL, '2021-12-02 16:30:28'),
(13, 27, ' 177  77 = 100 ', 1, NULL, '2021-12-02 16:31:04'),
(14, 27, ' Another method..\r\n(7+7) * (7 + (1/7)) = 100 ', 1, NULL, '2021-12-02 16:31:31'),
(15, 21, ' 888 + 88 + 8 + 8 + 8 = 1000\r\n\r\n', 1, NULL, '2021-12-02 16:33:00'),
(16, 22, ' 41 years ago, when Sally was 13 and her mother was 39.', 1, NULL, '2021-12-02 16:33:14'),
(17, 23, ' 1,2 and 3\r\nExplaination: 1+2+3=6 and 1*2*3=6', 1, NULL, '2021-12-02 16:34:01'),
(18, 24, ' 4 children get 1 apple each while the fifth child gets the basket with the remaining apple still in it.\r\n\r\n ', 1, NULL, '2021-12-02 16:34:30'),
(19, 25, ' 141', 1, NULL, '2021-12-02 16:34:46'),
(20, 20, ' A property of equilateral triangles includes that all of their angles are equal to 60 degrees. ... Since every equilateral triangle`s angles are 60 degrees, every equilateral triangle is similar to one another due to this AAA Postulate.', 1, NULL, '2021-12-02 16:36:15'),
(21, 20, ' An equiangular triangle has three equal sides, and it is the same as an equilateral triangle. In the given non-examples, all the figures are of triangles, but none of them is an equiangular triangle because: In a right-angled triangle, one of the interior angles is of 90&#730;.', 1, NULL, '2021-12-02 16:39:04'),
(22, 21, ' 8+8+8+88+888=1000', 1, NULL, '2021-12-02 16:40:50'),
(23, 20, '  For two triangles to be similar the angles in one triangle must have the same values as the angles in the other triangle. ... For the equilateral triangles since they always have 3 angles that are each 60° , any equilateral triangles will be similar.', 1, NULL, '2021-12-02 16:43:56'),
(24, 29, ' Given : x sin3 &#952; + y cos3 &#952; = sin &#952; cos &#952;<br>\r\n\r\n&#8658; (x sin &#952;) sin2 &#952; + (y cos &#952;) cos2 &#952; = sin &#952; cos &#952;<br>\r\n\r\n&#8658; (x sin &#952;) sin2 &#952; + (x sin &#952;) cos2 &#952; = sin &#952; cos &#952;  (&#8757;  y cos &#952; = x sin &#952;<br>\r\n\r\n&#8658; x sin &#952;(sin2 &#952; + cos2 &#952;) = sin &#952; cos &#952;\r\n\r\n&#8658; x sin &#952; = sin &#952; cos &#952;\r\n\r\n&#8658; x = cos &#952;         .(1)\r\n\r\nAgain    x sin &#952; = y cos &#952;\r\n\r\n&#8658; cos &#952; sin &#952;  = y cos &#952;\r\n\r\n&#8658; y = sin &#952;         .(2)\r\n\r\nSquaring and adding (1) and (2) we get the required result\r\n\r\nHence proved.', 1, NULL, '2021-12-02 20:21:21'),
(25, 1, 'Unit- Pascal or N/m2.', NULL, 1, '2021-12-02 20:25:12'),
(26, 29, ' (&#8757; y cos &#952; = x sin &#952;)<br>\r\n&#8658; x sin &#952;(sin2 &#952; + cos2 &#952;) = sin &#952; cos &#952; <br>&#8658; x sin &#952; = sin &#952; cos &#952; <br>&#8658; x = cos &#952; .(1)<br> Again x sin &#952; = y cos &#952; <br>&#8658; cos &#952; sin &#952; = y cos &#952; <br>&#8658; y = sin &#952; .(2) <br>\r\nIs it clear???\r\n', 1, NULL, '2021-12-02 20:27:20');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `name`, `email`, `password`, `status`) VALUES
(1, 'Yogita Patidar', 'yogi2603@gmail.com', '12345', 0),
(3, 'Sakshi Prajapat', 'sakshi123@gmail.com', '12345', 0),
(4, 'Anshita Verma', 'anshi1505@gmail.com', '12345', 0),
(5, 'Prateek Shah', 'prateek@gmail.com', '12345', 0),
(6, 'Nimesh Gupta', 'nimesh@gmail.com', '12345', 0),
(7, 'Neeti Sahni', 'neeti@gmail.com', '12345', 0),
(8, 'Radhika Jat', 'radha@gmail.com', '123456', 0),
(9, 'Nidhi Gupta', 'nidhi@gmail.com', '123345456568', 0),
(10, 'Kanushi Aapte', 'kanushi@gmail.com', '123345879dvg', 0),
(12, 'Kanushi Doshi', 'kanushia@gmail.com', '123456u', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`categoryid`),
  ADD UNIQUE KEY `categoryname` (`categoryname`);

--
-- Indexes for table `expert`
--
ALTER TABLE `expert`
  ADD PRIMARY KEY (`expertid`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_cid` (`categoryid`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`queid`),
  ADD KEY `fk_userId` (`userid`),
  ADD KEY `fk_categoryId` (`categoryid`);

--
-- Indexes for table `solution`
--
ALTER TABLE `solution`
  ADD PRIMARY KEY (`ansid`),
  ADD KEY `fk_queid` (`queid`),
  ADD KEY `fk_expertid` (`expertid`),
  ADD KEY `fk_user` (`userid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`),
  ADD KEY `email` (`email`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `expert`
--
ALTER TABLE `expert`
  MODIFY `expertid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `queid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `solution`
--
ALTER TABLE `solution`
  MODIFY `ansid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `expert`
--
ALTER TABLE `expert`
  ADD CONSTRAINT `fk_cid` FOREIGN KEY (`categoryid`) REFERENCES `category` (`categoryId`);

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `fk_categoryId` FOREIGN KEY (`categoryId`) REFERENCES `category` (`categoryId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_userId` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `solution`
--
ALTER TABLE `solution`
  ADD CONSTRAINT `fk_expertid` FOREIGN KEY (`expertid`) REFERENCES `expert` (`expertid`),
  ADD CONSTRAINT `fk_queid` FOREIGN KEY (`queid`) REFERENCES `question` (`queid`),
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
