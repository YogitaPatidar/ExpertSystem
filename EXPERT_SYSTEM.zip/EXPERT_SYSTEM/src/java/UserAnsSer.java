import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author lenovo
 */
@WebServlet(urlPatterns = {"/UserAnsSer"})
public class UserAnsSer extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        try {
            HttpSession session = request.getSession();
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
            Statement st = conn.createStatement();
            String query = "INSERT INTO `solution` (`ansid`, `queid`, `answer`, `expertid`, `userid`, `datetime`) VALUES (NULL, '1', 'Unit- Pascal or N/m2.', NULL, '1', current_timestamp())";
            int x = st.executeUpdate(query);
            if (x != 0) {
                response.sendRedirect("allQuestion.jsp");
            } else {
                response.sendRedirect("allQuestion.jsp?q=error...");
            }
        } catch (Exception ex) {
            out.print(ex.getMessage().toString());
        }
    }
}
