import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author lenovo
 */
@WebServlet(urlPatterns = {"/UpdateProfile"})
public class UpdateProfile extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
            Statement st = conn.createStatement();
            int x = st.executeUpdate("update user set password='"+request.getParameter("newpass")+"',name='"+request.getParameter("fname")+"' where userid='"+request.getParameter("userid")+"'");
            if (x != 0) {
                response.sendRedirect("adLogout.jsp?q=data updated successfully");
            } else {
                response.sendRedirect("userLogin.jsp?q=data not updated successfully");
            }
            conn.close();
        } catch (Exception ex) {
            out.print(ex.getMessage().toString());
        }
    }
}