import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/LoginSer"})
public class LoginSer extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
            Statement st = conn.createStatement();
            if (request.getParameter("type").equals("user")) {
                ResultSet res = st.executeQuery("select * from user where userid='" + request.getParameter("userid") + "' and password='" + request.getParameter("password") + "'");
                if (res.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("userID", res.getInt(1));
                    session.setAttribute("name", res.getString(2));
                    response.sendRedirect("userDashboard.jsp?q=" + res.getString(2));
                } else {
                    response.sendRedirect("userLogin.jsp?q=Incorrect Id or Password...");
                }
                res.close();
            } else if (request.getParameter("type").equals("expert")) {
                ResultSet res = st.executeQuery("select * from expert where expertid='" + request.getParameter("userid") + "' and password='" + request.getParameter("password") + "'");
                if (res.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("expertID", res.getInt(1));
                    session.setAttribute("name", res.getString(2));
                    session.setAttribute("cat", res.getString(5));
                    response.sendRedirect("expertDashboard.jsp?q=" + res.getString(2));
                } else {
                    response.sendRedirect("expertLogin.jsp?q=Incorrect Id or Password...");
                }
                res.close();
            } else if (request.getParameter("type").equals("admin")) {
                ResultSet res = st.executeQuery("select * from admin where adminid='" + request.getParameter("userid") + "' and password='" + request.getParameter("password") + "'");
                if (res.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("adminID", res.getString(1));
                    session.setAttribute("name", res.getString(3));
                    response.sendRedirect("adminDashboard.jsp?q=Login succesful...");
                } else {
                    response.sendRedirect("adminLogin.jsp?q=Incorrect Id or Password...");
                }
                res.close();
            }
            conn.close();
        } catch (ClassNotFoundException | SQLException | IOException ex) {
            out.print(ex.getMessage().toString());
        }
    }
}
