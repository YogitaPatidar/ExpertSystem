import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/askQuestionSer"})
public class askQuestionSer extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        try {
            HttpSession session = request.getSession();
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
            Statement st = conn.createStatement();  
            int x1=st.executeUpdate("INSERT INTO `question` (`queid`, `categoryid`, `title`, `userid`, `datetime`) VALUES (NULL, '"+request.getParameter("cat")+"', '"+request.getParameter("question")+"', '"+request.getParameter("id")+"', current_timestamp())");
            if(x1!=0){
                response.sendRedirect("askQuestion.jsp?q=Wait for expert to answer the question....");
            }
            
            conn.close();
           
        } catch (Exception ex) {
            out.print(ex);
        }    
    }
}
