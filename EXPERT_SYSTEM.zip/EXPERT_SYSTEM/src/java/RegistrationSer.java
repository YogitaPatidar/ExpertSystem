import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/RegistrationSer"})
public class RegistrationSer extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/expertsystem", "root", "");
            java.sql.Statement st = conn.createStatement();
            if (request.getParameter("type").equals("expert")) {
                int x = st.executeUpdate("insert INTO `expert` (`expertid`, `name`, `email`, `password`, `categoryid`, `status`) VALUES (NULL,'" + request.getParameter("fname") + "', '" + request.getParameter("email") + "', '" + request.getParameter("password") + "','" + request.getParameter("cat") + "', '" + request.getParameter("status") + "')");
                if (x != 0) {
                    response.sendRedirect("adRegisterExpert.jsp?q=Registration succesful...");
                } else {
                    response.sendRedirect("userSignUp.jsp?q=Registration not successful!!");
                }
            } else {
                int x = st.executeUpdate("insert into  `user` (`userid`, `name`, `email`, `password`, `status`) VALUES (NULL, '" + request.getParameter("fname") + "', '" + request.getParameter("email") + "', '" + request.getParameter("password") + "','0')");
                if (x != 0) {
                    response.sendRedirect("userSignUp.jsp?q=Registration succesful...");
                } else {
                    response.sendRedirect("userSignUp.jsp?q=Registration not successful!!");
                }  
            }
        } catch (ClassNotFoundException | SQLException ex) {
            out.print(ex.getMessage().toString());
        }
    }
}
